# exo-ml
Pip-installable Python package for exoplanet detection using machine learning.
